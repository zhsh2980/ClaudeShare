#!/usr/bin/env python3
import json
import sys
import subprocess
import os
import re
from pathlib import Path

def get_file_operation(tool_name, tool_input):
    """根据工具类型判断文件操作类型"""
    if tool_name == "Write":
        file_path = tool_input.get("file_path", "")
        if os.path.exists(file_path):
            return "Updated"
        else:
            return "Created"
    elif tool_name in ["Edit", "MultiEdit"]:
        return "Edited"
    elif tool_name == "NotebookEdit":
        return "Updated notebook"
    return "Modified"

def extract_file_path(tool_input):
    """从工具输入中提取文件路径"""
    file_path = tool_input.get("file_path", "")
    if file_path:
        return Path(file_path).name
    return "files"

def has_git_changes(cwd):
    """检查是否有 git 更改"""
    try:
        result = subprocess.run(
            ['git', 'status', '--porcelain'],
            cwd=cwd,
            capture_output=True,
            text=True
        )
        return bool(result.stdout.strip())
    except:
        return False

def create_commit(cwd, commit_message):
    """创建 git commit"""
    try:
        # 添加所有更改
        subprocess.run(
            ['git', 'add', '-A'],
            cwd=cwd,
            check=True,
            capture_output=True
        )

        # 创建 commit
        result = subprocess.run(
            ['git', 'commit', '-m', commit_message],
            cwd=cwd,
            capture_output=True,
            text=True
        )

        if result.returncode == 0:
            # 输出成功信息到 stderr（不会干扰 Claude）
            print(f"✓ Auto-commit: {commit_message}", file=sys.stderr)

        return result.returncode == 0
    except Exception as e:
        print(f"Error creating commit: {e}", file=sys.stderr)
        return False

def main():
    try:
        # 读取输入
        input_data = json.load(sys.stdin)
    except json.JSONDecodeError:
        # 如果无法解析 JSON，静默退出
        sys.exit(0)

    # 获取工具信息
    tool_name = input_data.get("tool_name", "")
    tool_input = input_data.get("tool_input", {})

    # 获取工作目录 - 使用环境变量PWD或当前目录
    cwd = os.environ.get('PWD', os.getcwd())

    # 如果有文件路径，尝试找到对应的git仓库
    file_path = tool_input.get("file_path", "")
    if file_path:
        # 获取文件所在目录
        if os.path.exists(file_path):
            file_dir = os.path.dirname(os.path.abspath(file_path))
            # 从文件目录向上寻找.git目录
            test_dir = file_dir
            while test_dir != "/" and test_dir:
                if os.path.exists(os.path.join(test_dir, '.git')):
                    cwd = test_dir
                    break
                test_dir = os.path.dirname(test_dir)

    # 检查是否是 git 仓库
    if not os.path.exists(os.path.join(cwd, '.git')):
        # 不是 git 仓库，静默退出
        sys.exit(0)

    # 检查是否有更改
    if not has_git_changes(cwd):
        # 没有更改，静默退出
        sys.exit(0)

    # 生成 checkpoint commit message
    # 尝试读取保存的用户 prompt（在 git 仓库根目录查找）
    prompt_text = ""
    temp_file = os.path.join(cwd, ".claude_current_prompt.txt")
    try:
        if os.path.exists(temp_file):
            with open(temp_file, 'r', encoding='utf-8') as f:
                prompt_text = f.read().strip()
    except Exception as e:
        print(f"Error reading prompt: {e}", file=sys.stderr)

    # 如果没有找到保存的 prompt，使用工具信息作为备选
    if not prompt_text:
        operation = get_file_operation(tool_name, tool_input)
        file_name = extract_file_path(tool_input)
        prompt_text = f"{operation} {file_name}"[:15]

    commit_message = f"checkpoint:{prompt_text}"

    # 创建 commit
    create_commit(cwd, commit_message)

    # 正常退出，不阻塞 Claude
    sys.exit(0)

if __name__ == "__main__":
    main()