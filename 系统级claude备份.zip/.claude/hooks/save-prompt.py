#!/usr/bin/env python3
import json
import sys
import os
import tempfile
import re

def clean_prompt_for_commit(prompt):
    """提取 prompt 前 50 个字符并清理特殊字符"""
    # 提取前 50 个字符
    short_prompt = prompt[:50] if len(prompt) > 50 else prompt

    # 移除换行符和多余空格
    short_prompt = ' '.join(short_prompt.split())

    # 替换或移除可能导致问题的特殊字符
    # 保留中文、英文、数字、空格、@、:和常见标点
    short_prompt = re.sub(r'["\'\`\$\!\#\%\^\&\*\(\)\[\]\{\}\|\\\<\>\?\/\;]', '', short_prompt)

    # 如果处理后为空，使用默认值
    if not short_prompt.strip():
        short_prompt = "auto-save"

    return short_prompt.strip()

def main():
    try:
        # 读取输入
        input_data = json.load(sys.stdin)

        # 调试：记录接收到的输入
        debug_file = os.path.expanduser("~/.claude/debug_user_prompt_submit.json")
        with open(debug_file, 'w', encoding='utf-8') as f:
            json.dump(input_data, f, ensure_ascii=False, indent=2)
    except json.JSONDecodeError:
        # 如果无法解析 JSON，记录错误并静默退出
        with open(os.path.expanduser("~/.claude/debug_user_prompt_submit.txt"), 'w') as f:
            f.write("JSON decode error\n")
        sys.exit(0)

    # 获取 prompt 和工作目录
    prompt = input_data.get("prompt", "")
    # UserPromptSubmit hook 没有 cwd 字段，使用环境变量或当前目录
    cwd = os.environ.get('PWD', os.getcwd())

    if prompt:
        # 清理 prompt
        clean_prompt = clean_prompt_for_commit(prompt)

        # 保存到工程目录的临时文件
        temp_file = os.path.join(cwd, ".claude_current_prompt.txt")
        try:
            with open(temp_file, 'w', encoding='utf-8') as f:
                f.write(clean_prompt)
        except Exception as e:
            print(f"Error saving prompt: {e}", file=sys.stderr)

    # 正常退出，不阻塞 Claude
    sys.exit(0)

if __name__ == "__main__":
    main()